-- ============================================================
-- 単語学習機能（間隔反復・小テスト） テーブル設計
-- 対象: Supabase (PostgreSQL)
-- 作成日: 2026-08-11
-- 参考: expressions_schema.sql と同じ設計思想（コンテンツは公開範囲を絞ってanon/authenticated
--       に開放、書き込みはservice_role経由のみ）。
-- ============================================================

-- ------------------------------------------------------------
-- コード自動採番用シーケンス（VOC-0001, VOC-0002 ... の形式）
-- ------------------------------------------------------------
create sequence if not exists public.vocabulary_code_seq
  start 1
  increment 1;

-- ------------------------------------------------------------
-- 単語コンテンツ本体
-- ------------------------------------------------------------
create table if not exists public.vocabulary (
  id                    uuid primary key default gen_random_uuid(),

  code                  text not null unique
                        default ('VOC-' || lpad(nextval('public.vocabulary_code_seq')::text, 4, '0')),

  -- 拡張軸。将来カテゴリを分ける場合はここに新しい値を追加する想定（expressions.categoryと同じ考え方）
  category              text not null default '単語',

  word_en               text not null,
  part_of_speech        text not null,
  meaning_ja            text not null,

  example_en            text,
  example_ja            text,

  synonyms              text[],

  -- 専門分野タグ（財務・法務・ITなど）。将来の拡張軸で、当面は全てNULL（一般語彙のみ）。
  -- 値を追加する際は、scene_tags/intent_tagsと同様にCHECK制約を別マイグレーションで追加する。
  business_field        text[],

  -- 資格試験の頻出タグ（例: ['TOEIC']）。categoryとは独立した横断タグ。
  -- 「TOEIC単語」のような別カテゴリは作らず、通常の単語プールにこのタグを付与する形で吸収している
  -- （2026-08-15のマイグレーションでTOEIC単語カテゴリをこの列に統合）。
  -- CHECK制約はあえて付けない（将来「英検」などを追加してもマイグレーション不要にするため）。
  exam_tags             text[],

  level                 text not null,
  usage_notes           text,
  verification_status   text not null default 'AI生成のみ',
  publish_status        text not null default '下書き',

  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),

  constraint chk_vocabulary_level_valid check (
    level in ('初級','中級','上級')
  ),
  constraint chk_vocabulary_verification_status_valid check (
    verification_status in ('AI生成のみ','クロスチェック済み','ネイティブ確認済み')
  ),
  constraint chk_vocabulary_publish_status_valid check (
    publish_status in ('下書き','公開')
  )
);

comment on table public.vocabulary is 'ビジネス英単語学習機能（間隔反復・小テスト）のコンテンツストック。1行=1単語。';
comment on column public.vocabulary.business_field is '専門分野タグ（財務・法務・ITなど）。将来の拡張軸。現時点では全てNULL（一般語彙のみ）。';
comment on column public.vocabulary.exam_tags is '資格試験の頻出タグ（例: TOEIC）。categoryとは独立した横断タグ。将来英検などを追加してもCHECK変更不要。';

create trigger trg_vocabulary_updated_at
  before update on public.vocabulary
  for each row execute function public.set_updated_at();

create index if not exists idx_vocabulary_published
  on public.vocabulary (level)
  where publish_status = '公開';
create index if not exists idx_vocabulary_business_field
  on public.vocabulary using gin (business_field);
create index if not exists idx_vocabulary_exam_tags
  on public.vocabulary using gin (exam_tags);

alter table public.vocabulary enable row level security;

create policy "公開済み単語は誰でも閲覧可"
  on public.vocabulary
  for select
  to anon, authenticated
  using (publish_status = '公開');

-- insert/update/delete のポリシーは意図的に作成しない
-- → コンテンツ投入・編集は service_role キー（管理側）からのみ行う

-- ------------------------------------------------------------
-- ユーザーごとの学習進捗（間隔反復のSRS状態）
-- 「学習リストに追加」した単語だけ行を持つ。box_levelは1〜5（Leitner箱方式）。
--
-- 箱と復習間隔の対応（アプリ側のロジック。DB上には持たない）:
--   box 1 → 1日後 / box 2 → 3日後 / box 3 → 1週間後 / box 4 → 1ヶ月後 / box 5 → 3ヶ月後
--   正解: box+1（最大5） / 不正解: box=1に戻す
-- ------------------------------------------------------------
create table if not exists public.word_review_progress (
  id                    uuid primary key default gen_random_uuid(),
  user_id               uuid not null references auth.users(id) on delete cascade,
  vocabulary_id         uuid not null references public.vocabulary(id) on delete cascade,

  box_level             int not null default 1,
  next_review_date      date not null default current_date,
  correct_streak        int not null default 0,
  total_reviews         int not null default 0,
  last_result           text,

  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),

  constraint chk_word_review_box_level_valid check (box_level between 1 and 5),
  constraint chk_word_review_last_result_valid check (last_result is null or last_result in ('correct','incorrect')),
  constraint uq_word_review_user_vocab unique (user_id, vocabulary_id)
);

comment on table public.word_review_progress is 'ユーザーごとの単語学習進捗（間隔反復のLeitner箱状態）。学習リストに追加した単語のみ行を持つ。';

create trigger trg_word_review_progress_updated_at
  before update on public.word_review_progress
  for each row execute function public.set_updated_at();

create index if not exists idx_word_review_progress_due
  on public.word_review_progress (user_id, next_review_date);

-- ------------------------------------------------------------
-- RLS: 本人のデータのみ参照・書き込み可（service_role経由でなくクライアントから
-- 直接操作する想定はないが、将来クライアントSDKから直接叩く可能性に備えて
-- 本人 scoped のRLSをフルセットで用意しておく）
-- ------------------------------------------------------------
alter table public.word_review_progress enable row level security;

create policy "本人のみ参照可"
  on public.word_review_progress for select to authenticated
  using (auth.uid() = user_id);

create policy "本人のみ追加可"
  on public.word_review_progress for insert to authenticated
  with check (auth.uid() = user_id);

create policy "本人のみ更新可"
  on public.word_review_progress for update to authenticated
  using (auth.uid() = user_id);

create policy "本人のみ削除可"
  on public.word_review_progress for delete to authenticated
  using (auth.uid() = user_id);

-- ============================================================
-- 今後、専門分野（財務・法務・ITなど）を追加する場合
-- ============================================================
-- alter table public.vocabulary add constraint chk_vocabulary_business_field_valid check (
--   business_field is null or business_field <@ array['財務','法務','IT','マーケティング', ...]::text[]
-- );
-- のような形でCHECK制約を追加するマイグレーションを1本流すだけでよい（テーブル構造の変更は不要）。
