-- ============================================================
-- is_premium列の追加 + デモ用のPro限定フラグ設定（2026-08-01）
-- Supabase SQL Editorで実行。何度実行しても安全。
-- ============================================================

alter table public.expressions
  add column if not exists is_premium boolean not null default false;

comment on column public.expressions.is_premium is
  'Pro/Premium限定表現。trueでもフレーズ本体(expression_en)はFreeにも見せ、意味・例文等をアプリ側でマスクする運用。';

-- ------------------------------------------------------------
-- デモ用に「意味が気になる」タイプの表現を8件だけPro限定にしている。
-- あくまで動作確認用の仮選定なので、実際にShorts動画で取り上げた表現に
-- 合わせて、下のUPDATE文をその都度codeを差し替えて実行していく運用にする。
-- ------------------------------------------------------------
update public.expressions
set is_premium = true
where code in (
  'EX-0001', -- Let's circle back to that.
  'EX-0003', -- Let's take this offline.
  'EX-0009', -- Just circling back on this.
  'EX-0020', -- That's a dealbreaker for us.
  'EX-0023', -- Let's table this discussion.
  'EX-0035', -- I'll loop in Sarah on this.
  'EX-0043', -- I'm not in a position to make that call right now.
  'EX-0050'  -- Let's not lose sight of the bigger picture.
);

-- 確認用: Pro限定になっている表現の一覧
-- select code, expression_en from public.expressions where is_premium order by code;
