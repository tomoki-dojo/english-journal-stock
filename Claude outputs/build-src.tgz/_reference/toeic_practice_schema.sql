-- ============================================================
-- TOEIC演習機能（Part5形式クイズ） テーブル設計
-- 対象: Supabase (PostgreSQL)
-- 作成日: 2026-08-15
-- 方針: vocabulary_schema.sql / expressions_schema.sql と同じ設計思想
--       （コンテンツはanon/authenticatedに公開範囲を絞って開放、書き込みはservice_role経由のみ）。
--
-- 将来Part1〜4・6・7を追加する際に構造変更が要らないよう、
-- 「設問（toeic_questions）」と「設問が共有する素材＝音声/画像/長文（toeic_passages）」を分けてある。
-- Part5は素材を持たない設問（passage_id = null）として扱う。
-- Part1・2（選択肢が音声）に対応する際は、toeic_questionsに
-- choice_audio_urls / question_audio_url のようなnullable列を追加するだけで済む設計にしている
-- （既存行・既存列の変更は不要。詳細は過去のチャット/設計メモ参照）。
-- ============================================================

-- ------------------------------------------------------------
-- 設問が共有する素材（音声・画像・長文）。Part5では未使用（行を作らない）。
-- Part3/4（会話・トーク）、Part6（長文穴埋め）、Part7（読解）で、
-- 1つの素材に複数の設問がぶら下がる構造を扱うための置き場。
-- ------------------------------------------------------------
create sequence if not exists public.toeic_passages_code_seq
  start 1
  increment 1;

create table if not exists public.toeic_passages (
  id            uuid primary key default gen_random_uuid(),
  code          text not null unique
                default ('TPSG-' || lpad(nextval('public.toeic_passages_code_seq')::text, 4, '0')),

  part          int not null,
  -- 素材の種類。CHECKはあえて緩め（新Part追加時にマイグレーション不要にするため）
  type          text not null,

  content_text  text, -- 読解文・穴埋め文章など（音声のみの素材ではnull）
  audio_url     text, -- 会話・トークの音声（テキストのみの素材ではnull）
  image_url     text, -- 図表・写真（Part7の一部・Part1で使用予定、当面null）

  verification_status text not null default 'AI生成のみ',
  publish_status       text not null default '下書き',

  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),

  constraint chk_toeic_passages_part_valid check (part between 1 and 7),
  constraint chk_toeic_passages_verification_status_valid check (
    verification_status in ('AI生成のみ','クロスチェック済み','ネイティブ確認済み')
  ),
  constraint chk_toeic_passages_publish_status_valid check (
    publish_status in ('下書き','公開')
  )
);

comment on table public.toeic_passages is
  'TOEIC演習で複数設問が共有する素材（音声・画像・長文）。Part5は素材を持たないため行を作らない。';

create trigger trg_toeic_passages_updated_at
  before update on public.toeic_passages
  for each row execute function public.set_updated_at();

alter table public.toeic_passages enable row level security;

create policy "公開済み素材は誰でも閲覧可"
  on public.toeic_passages
  for select
  to anon, authenticated
  using (publish_status = '公開');

-- insert/update/delete のポリシーは意図的に作成しない（service_role経由のみ）

-- ------------------------------------------------------------
-- 設問本体
-- ------------------------------------------------------------
create sequence if not exists public.toeic_questions_code_seq
  start 1
  increment 1;

create table if not exists public.toeic_questions (
  id            uuid primary key default gen_random_uuid(),
  code          text not null unique
                default ('TQ-' || lpad(nextval('public.toeic_questions_code_seq')::text, 4, '0')),

  -- passage_idがある場合はpassagesのpartと重複するが、Part5のように
  -- passageを持たない設問が単独で存在するため、この列は必須にしてある。
  part          int not null,
  passage_id    uuid references public.toeic_passages(id) on delete cascade,
  order_in_passage int, -- 同じpassageに複数設問がある場合の並び順。passage_idがnullなら未使用。

  -- 出題カテゴリ（Part5なら文法項目、Part7なら設問タイプなど）。
  -- category/business_fieldと同じ考え方であえてCHECKなしにしている
  -- （Partが増えるたびにタグ語彙が変わるため、都度マイグレーションが要らないようにする）。
  skill_tag     text not null,

  question_text text not null, -- Part5は空所付きの1文。Part2は音声のみのため将来的に空文字許容の想定。
  choices       text[] not null,
  correct_index int not null,
  explanation_ja text not null,

  -- 関連する単語・表現（TOEIC単語などとの実務接続を意識したクロスリンク。任意）
  related_vocabulary_id uuid references public.vocabulary(id) on delete set null,

  level         text not null,
  verification_status text not null default 'AI生成のみ',
  publish_status       text not null default '下書き',

  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),

  constraint chk_toeic_questions_part_valid check (part between 1 and 7),
  constraint chk_toeic_questions_choices_len check (array_length(choices, 1) between 2 and 5),
  constraint chk_toeic_questions_correct_index_valid check (
    correct_index >= 0 and correct_index < array_length(choices, 1)
  ),
  constraint chk_toeic_questions_level_valid check (level in ('初級','中級','上級')),
  constraint chk_toeic_questions_verification_status_valid check (
    verification_status in ('AI生成のみ','クロスチェック済み','ネイティブ確認済み')
  ),
  constraint chk_toeic_questions_publish_status_valid check (
    publish_status in ('下書き','公開')
  )
);

comment on table public.toeic_questions is
  'TOEIC演習の設問本体。1行=1問。Part5はpassage_id無しの単独設問として扱う。';
comment on column public.toeic_questions.skill_tag is
  '出題カテゴリ（Part5は文法項目名）。Partごとにタグ語彙が変わるためCHECKなし。';

create trigger trg_toeic_questions_updated_at
  before update on public.toeic_questions
  for each row execute function public.set_updated_at();

create index if not exists idx_toeic_questions_published
  on public.toeic_questions (part, skill_tag)
  where publish_status = '公開';
create index if not exists idx_toeic_questions_passage
  on public.toeic_questions (passage_id);

alter table public.toeic_questions enable row level security;

create policy "公開済み設問は誰でも閲覧可"
  on public.toeic_questions
  for select
  to anon, authenticated
  using (publish_status = '公開');

-- insert/update/delete のポリシーは意図的に作成しない（service_role経由のみ）

-- ------------------------------------------------------------
-- 回答ログ（弱点タグ集計・診断機能用）
-- 診断UIは未実装だが、公開開始時点からログを取り始めないと
-- 診断機能着手までのデータが失われるため、③の時点で作っておく。
-- ------------------------------------------------------------
create table if not exists public.toeic_answer_log (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references auth.users(id) on delete cascade,
  question_id   uuid not null references public.toeic_questions(id) on delete cascade,
  is_correct    boolean not null,
  answered_at   timestamptz not null default now()
);

comment on table public.toeic_answer_log is
  'TOEIC演習の回答履歴。弱点タグ集計（診断機能）のための素データ。1行=1回答。';

create index if not exists idx_toeic_answer_log_user
  on public.toeic_answer_log (user_id, answered_at);
create index if not exists idx_toeic_answer_log_question
  on public.toeic_answer_log (question_id);

alter table public.toeic_answer_log enable row level security;

create policy "本人の回答履歴のみ参照可"
  on public.toeic_answer_log for select to authenticated
  using (auth.uid() = user_id);

-- insert/update/delete のポリシーは意図的に作成しない
-- → 回答ログの書き込みは service_role（アプリのAPIルート）からのみ行う

-- ============================================================
-- 今後、Part1・2（選択肢が音声）に対応する場合
-- ============================================================
-- alter table public.toeic_questions add column question_audio_url text;
-- alter table public.toeic_questions add column choice_audio_urls text[];
-- のような形でnullable列を追加するマイグレーションを1本流すだけでよい
-- （既存のPart5〜7の行・列は無変更のまま）。
