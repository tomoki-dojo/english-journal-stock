-- ============================================================
-- お気に入り（マイリスト）テーブル設計
-- 対象: Supabase (PostgreSQL)
-- ============================================================

create table if not exists public.saved_expressions (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references auth.users(id) on delete cascade,
  expression_id uuid not null references public.expressions(id) on delete cascade,
  created_at    timestamptz not null default now(),

  unique (user_id, expression_id)
);

comment on table public.saved_expressions is
  'ユーザーごとのお気に入り（マイリスト）。件数上限はアプリ側（Freeプランのみ）で制御する。';

create index if not exists idx_saved_expressions_user on public.saved_expressions(user_id);

-- ------------------------------------------------------------
-- RLS
-- 運用方針：本人の行だけ読み書き可能。それ以外はservice_role経由のみ。
-- ------------------------------------------------------------
alter table public.saved_expressions enable row level security;

drop policy if exists "本人の保存分のみ閲覧可" on public.saved_expressions;
create policy "本人の保存分のみ閲覧可"
  on public.saved_expressions
  for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "本人のみ保存可" on public.saved_expressions;
create policy "本人のみ保存可"
  on public.saved_expressions
  for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "本人のみ削除可" on public.saved_expressions;
create policy "本人のみ削除可"
  on public.saved_expressions
  for delete
  to authenticated
  using (auth.uid() = user_id);
