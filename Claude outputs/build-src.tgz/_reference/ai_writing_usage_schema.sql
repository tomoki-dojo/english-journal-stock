-- ============================================================
-- AI添削機能（実務ライティング添削）利用回数カウンタ テーブル設計
-- 対象: Supabase (PostgreSQL)
-- 作成日: 2026-08-13
-- 方針: ユーザーが入力した文章そのものは保存しない（プライバシー配慮・実装の単純化）。
--       Free/Proの月次回数上限を判定するためのカウンタのみを持つ。
-- ============================================================

create table if not exists public.ai_writing_usage (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references auth.users(id) on delete cascade,
  month_key     text not null, -- JST基準 'YYYY-MM'（例: '2026-08'）。daily-rotation.tsのgetTodayDateKeyと同じJST基準で算出する。
  request_count int not null default 0,

  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),

  constraint uq_ai_writing_usage_user_month unique (user_id, month_key)
);

comment on table public.ai_writing_usage is
  'AI添削機能（実務ライティング添削）の月次利用回数カウンタ。Free/Proの回数上限判定に使用。ユーザーが入力した文章そのものは保存しない。';

create trigger trg_ai_writing_usage_updated_at
  before update on public.ai_writing_usage
  for each row execute function public.set_updated_at();

create index if not exists idx_ai_writing_usage_user_month
  on public.ai_writing_usage(user_id, month_key);

-- ------------------------------------------------------------
-- RLS
-- 運用方針：本人の回数は閲覧可能（将来「今月あとN回」をUIに出す場合に備える）。
-- 書き込みは service_role（APIルート内、利用のたびにupsertでカウントアップ）のみ。
-- ------------------------------------------------------------
alter table public.ai_writing_usage enable row level security;

create policy "本人の利用回数のみ参照可"
  on public.ai_writing_usage for select to authenticated
  using (auth.uid() = user_id);

-- insert/update/delete のポリシーは意図的に作成しない
-- → カウンタの読み書きは service_role（アプリのAPIルート）からのみ行う

-- ------------------------------------------------------------
-- 月次上限（アプリ側のロジック。DB上には持たない）
--   free: 月3回まで
--   pro / premium: 月20回まで
-- ------------------------------------------------------------
