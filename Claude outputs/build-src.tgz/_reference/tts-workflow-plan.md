# 音声生成 n8nワークフロー設計

作成日：2026-07-15

## 全体パイプライン

「案（アプリとYouTube）」→「YouTube台本」→「音声ファイル」

1. **案（アプリとYouTube）** = 「英語Shorts制作管理」タブ（1行＝1動画、テーマ・ステータス管理）
2. **YouTube台本** = 「台本」タブ（1行＝1カット。話者・セリフ・型・音声化フラグ）
3. **音声ファイル** = 本ワークフローが「台本」タブを読んでGoogle Cloud TTSを叩き、Driveに保存してリンクを書き戻す

## 前提：スプシ側の準備（実施済み）

**台本タブの列**：動画ID／順番／型／話者／言語／セリフ・テロップ／表情／音声化（要・不要）／音声ファイル（書き戻し用、空欄）／備考／読み上げテキスト

**話者ボイス設定タブの列**：話者／言語／Google TTSボイス名／備考

ポイントは「セリフ・テロップ」と「読み上げテキスト」を分けたこと。セリフ・テロップには「（内心）」のような演出注記を残し、読み上げテキストはTTSにそのまま投げられるクリーンな文字列だけにする。混ぜるとTTSが「内心」まで読み上げてしまう。

話者ボイス設定は「話者」単独ではなく「話者×言語」で引く。クマは日本語（内心）と英語（決め台詞）の両方を喋るため、同じキャラでも行によって声を変える必要がある。

## ワークフロー構成（手動トリガー）

| # | ノード | 内容 |
|---|---|---|
| 1 | Manual Trigger | 台本を書き終えたタイミングで手動実行。頻度が低いのでcron不要 |
| 2 | Google Sheets（取得） | 話者ボイス設定タブを全行取得 |
| 3 | Google Sheets（取得） | 台本タブを全行取得（row_numberも一緒に取得される） |
| 4 | Code（JS） | ・話者ボイス設定を `話者_言語` キーのルックアップに変換<br>・台本の行を「音声化＝要」かつ「音声ファイル＝空欄」だけにフィルタ<br>・各行に ttsVoice（ルックアップ結果）、languageCode（en→en-US、ja→ja-JP）、ファイル名 `video{動画ID}_line{順番}_{話者}.mp3` を付与 |
| 5 | HTTP Request | POST `https://texttospeech.googleapis.com/v1/text:synthesize?key={API_KEY}`<br>body: `input.text`=読み上げテキスト、`voice.languageCode`/`voice.name`＝手順4の値、`audioConfig.audioEncoding`="MP3"<br>n8nは対象行を1件ずつ自動でこのノードに流すのでループ処理は不要 |
| 6 | Convert to File | レスポンスの `audioContent`（Base64）をバイナリのmp3ファイルに変換 |
| 7 | Google Drive（アップロード） | 音声素材用フォルダに、手順4のファイル名でアップロード |
| 8 | Google Sheets（更新） | マッチ列は `row_number`（手順3のGet Rowsに含まれるメタ情報をそのまま使う）。台本タブの「音声ファイル」列にDriveのリンクを書き戻す |

## 認証

Google Cloud TTS APIは「Text-to-Speech APIのみに制限したAPIキー」で十分。OAuth/サービスアカウントは今回はオーバースペック。

## 再実行時の安全性

生成済みの行は「音声ファイル」列が埋まるため、手順4のフィルタ条件（音声ファイル＝空欄）に引っかからなくなる。同じワークフローを台本追加のたびに再実行しても、既存行を重複生成しない。

## 動作確認済み（2026-07-26）

n8nワークフロー「英語Shorts 台本→TTS音声生成」を実際にインポート・設定し、動画#1の台本（6行）で最初から最後まで正常に実行できることを確認した。

つまずいたポイントと解決策：

- **`$env`直参照がブロックされる**：`N8N_BLOCK_ENV_ACCESS_IN_NODE`によりノード式からの環境変数アクセスは不可。APIキーはCredential（Query Auth）経由で渡す方式に変更
- **Query AuthのName欄**：Credential編集画面の「Name」欄がそのまま送信されるクエリパラメータ名になる。ここに`key`と入れる必要がある（credential自体の表示名とは別物で紛らわしい）
- **Google DriveのService Account方式は詰まりやすい**：①既存サービスアカウントが別プロジェクトに紐づいていて権限不足→②新規プロジェクトでもサービスアカウントキー発行が組織ポリシーでブロック、という二重の壁にあたった。最終的にGoogle SheetsノードろSheets同様、OAuth2方式（既存のOAuthクライアントのClient ID/Secretを流用、Secretは新規発行）に切り替えて解決
- **CodeノードのpairedItem**：新しいアイテムを`json`だけで作ると、後段の`$('Get 台本').item`が解決できずエラーになる。`pairedItem: { item: i }`を明示する必要がある

これらの修正はすべて`_reference/tts-generation-workflow.json`にも反映済み。

## 音声エンジンの使い分け（2026-07-26〜）

聴いてみたところNeural2の日本語ボイスが「普通すぎる」との判断になり、方針変更：

- 英語（同僚のセリフ、クマの決め台詞）→ 引き続きGoogle Cloud TTS（Neural2）
- 日本語（クマの内心モノローグ）→ VOICEVOXに変更。あえて機械的・アニメ的な声質を活かす方向

話者ボイス設定タブに`音声エンジン`／`VOICEVOXスピーカーID`列を追加済み（クマ・ja行はVOICEVOX・speaker=3を仮設定、実際のキャラは`/speakers`エンドポイントで確認して選定要）。

n8n側は以下の構成に変更中：

```
Code → IF（engine=="VOICEVOX"?）
  true分岐  → VOICEVOX Query（/audio_query）→ VOICEVOX Synthesis（/synthesis、バイナリwav直接返却）
  false分岐 → Google Cloud TTS（既存）→ Convert to File（mp3化）
両分岐 → Merge（Append） → Google Drive（拡張子はCodeノードのengineで動的に.wav/.mp3を判定）→ Update 台本
```

VOICEVOX EngineはVPS上にDockerコンテナとして追加が必要（n8nと同じdocker-composeファイル・同じネットワークに追加し、`http://voicevox:50021`で疎通する想定）。

## 保留・未確認事項

- VOICEVOX Engineのコンテナ追加（VPS側、未実施）
- n8nワークフローへのIF/VOICEVOX Query/VOICEVOX Synthesis/Mergeノード追加（未実施）
- VOICEVOXのキャラクター・speakerID選定（`/speakers`で一覧確認要、現在は仮でID=3）
- 各VOICEVOXキャラの利用規約確認（収益化前提のYouTubeでの利用可否・クレジット表記要否）
- 動画#2〜10の台本タブへの入力（動画#1のみ入力済み、テンプレとして流用）
