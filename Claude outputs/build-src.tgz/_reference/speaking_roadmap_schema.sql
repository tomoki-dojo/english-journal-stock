-- スピーキング・ロードマップ機能（Stage1〜5、アイソメ都市、エラータグ、デイリーストリーク）
-- 参照: brand/isometric-city-asset-spec.md, 一連の設計会話ログ
-- 命名・RLS・トリガーの規約は他の _reference/*_schema.sql に準拠

-- =========================================
-- 1. speaking_stage_progress
--    フレーズ（単語 or 表現）×Stage単位の習熟状況
-- =========================================
create table if not exists public.speaking_stage_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  phrase_id uuid not null,
  phrase_source text not null,
  stage smallint not null,
  status text not null default '未着手',
  correct_streak int not null default 0,
  last_result text,
  last_practiced_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint chk_speaking_stage_progress_source check (phrase_source in ('vocabulary', 'expression')),
  constraint chk_speaking_stage_progress_stage check (stage between 1 and 5),
  constraint chk_speaking_stage_progress_status check (status in ('未着手', '練習中', '習得済み')),
  constraint uq_speaking_stage_progress_user_phrase_stage unique (user_id, phrase_id, phrase_source, stage)
);

comment on table public.speaking_stage_progress is 'フレーズ（単語/表現）ごとの、スピーキングロードマップの各Stageでの習熟状況。';
comment on column public.speaking_stage_progress.phrase_source is 'phrase_idがvocabularyテーブルかexpressionsテーブルかの区別（アプリ側でJOIN先を出し分ける、FK制約なし）。';
comment on column public.speaking_stage_progress.stage is '1=音読/シャドーイング, 2=瞬間英作文, 3〜5は今後拡張。';
comment on column public.speaking_stage_progress.correct_streak is '「言えた」の連続回数。間隔反復の間隔調整に使う。';

create index if not exists idx_speaking_stage_progress_user on public.speaking_stage_progress(user_id);
create index if not exists idx_speaking_stage_progress_user_stage on public.speaking_stage_progress(user_id, stage);
create index if not exists idx_speaking_stage_progress_phrase on public.speaking_stage_progress(phrase_id, phrase_source);

drop trigger if exists trg_speaking_stage_progress_updated_at on public.speaking_stage_progress;
create trigger trg_speaking_stage_progress_updated_at
  before update on public.speaking_stage_progress
  for each row execute function public.set_updated_at();

alter table public.speaking_stage_progress enable row level security;

drop policy if exists "本人の進捗のみ閲覧可" on public.speaking_stage_progress;
create policy "本人の進捗のみ閲覧可"
  on public.speaking_stage_progress for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "本人の進捗のみ登録可" on public.speaking_stage_progress;
create policy "本人の進捗のみ登録可"
  on public.speaking_stage_progress for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "本人の進捗のみ更新可" on public.speaking_stage_progress;
create policy "本人の進捗のみ更新可"
  on public.speaking_stage_progress for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "本人の進捗のみ削除可" on public.speaking_stage_progress;
create policy "本人の進捗のみ削除可"
  on public.speaking_stage_progress for delete
  to authenticated
  using (auth.uid() = user_id);


-- =========================================
-- 2. user_error_tag_stats
--    前置詞・冠詞・時制などの「エラータグ」単位の弱点集計
-- =========================================
create table if not exists public.user_error_tag_stats (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  error_tag text not null,
  miss_count int not null default 0,
  mastered boolean not null default false,
  last_missed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint uq_user_error_tag_stats_user_tag unique (user_id, error_tag)
);

comment on table public.user_error_tag_stats is 'ユーザーごとの文法エラータグ（前置詞・冠詞・時制など）の弱点集計。寄り道コンテンツの出題判定に使う。';
comment on column public.user_error_tag_stats.error_tag is '自由記述のタグ名（例: preposition, article, tense_perfect）。タグ語彙が増えてもマイグレーション不要にするため意図的にCHECK制約なし。';

create index if not exists idx_user_error_tag_stats_user on public.user_error_tag_stats(user_id);

drop trigger if exists trg_user_error_tag_stats_updated_at on public.user_error_tag_stats;
create trigger trg_user_error_tag_stats_updated_at
  before update on public.user_error_tag_stats
  for each row execute function public.set_updated_at();

alter table public.user_error_tag_stats enable row level security;

drop policy if exists "本人のエラータグ集計のみ閲覧可" on public.user_error_tag_stats;
create policy "本人のエラータグ集計のみ閲覧可"
  on public.user_error_tag_stats for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "本人のエラータグ集計のみ登録可" on public.user_error_tag_stats;
create policy "本人のエラータグ集計のみ登録可"
  on public.user_error_tag_stats for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "本人のエラータグ集計のみ更新可" on public.user_error_tag_stats;
create policy "本人のエラータグ集計のみ更新可"
  on public.user_error_tag_stats for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);


-- =========================================
-- 3. daily_streak_log
--    練習した日を1行1日で記録（ストリーク集計の元データ）
-- =========================================
create table if not exists public.daily_streak_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  practiced_date date not null,
  created_at timestamptz not null default now(),
  constraint uq_daily_streak_log_user_date unique (user_id, practiced_date)
);

comment on table public.daily_streak_log is 'ユーザーが練習した日を1行1日で記録する追記専用ログ。連続日数はここから都度計算する（カウンタのズレを避けるため）。';

create index if not exists idx_daily_streak_log_user on public.daily_streak_log(user_id, practiced_date desc);

alter table public.daily_streak_log enable row level security;

drop policy if exists "本人のストリークログのみ閲覧可" on public.daily_streak_log;
create policy "本人のストリークログのみ閲覧可"
  on public.daily_streak_log for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "本人のストリークログのみ登録可" on public.daily_streak_log;
create policy "本人のストリークログのみ登録可"
  on public.daily_streak_log for insert
  to authenticated
  with check (auth.uid() = user_id);


-- =========================================
-- 4. user_roadmap_state
--    ユーザー1人につき1行。現在地・累計値のキャッシュ
-- =========================================
create table if not exists public.user_roadmap_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  current_stage smallint not null default 1,
  onboarding_quiz_completed boolean not null default false,
  onboarding_track text,
  total_mastered_count int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint chk_user_roadmap_state_stage check (current_stage between 1 and 5),
  constraint chk_user_roadmap_state_track check (onboarding_track is null or onboarding_track in ('daily', 'business'))
);

comment on table public.user_roadmap_state is 'ユーザーごとのロードマップ全体の現在地・累計値。都市ビジュアル描画時の起点データ。';
comment on column public.user_roadmap_state.total_mastered_count is '習得済みフレーズの累計数（窓の在室オーバーレイ・小物パーツ・増築・新築の判定に使う）。speaking_stage_progressから都度集計すると重いため、更新のたびにキャッシュする値。';
comment on column public.user_roadmap_state.onboarding_track is '「会話クイズ」診断の結果、日常会話寄りかビジネス寄りかの初期振り分け。';

drop trigger if exists trg_user_roadmap_state_updated_at on public.user_roadmap_state;
create trigger trg_user_roadmap_state_updated_at
  before update on public.user_roadmap_state
  for each row execute function public.set_updated_at();

alter table public.user_roadmap_state enable row level security;

drop policy if exists "本人のロードマップ状態のみ閲覧可" on public.user_roadmap_state;
create policy "本人のロードマップ状態のみ閲覧可"
  on public.user_roadmap_state for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "本人のロードマップ状態のみ登録可" on public.user_roadmap_state;
create policy "本人のロードマップ状態のみ登録可"
  on public.user_roadmap_state for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "本人のロードマップ状態のみ更新可" on public.user_roadmap_state;
create policy "本人のロードマップ状態のみ更新可"
  on public.user_roadmap_state for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);
