-- ============================================================
-- 英語アプリ（表現×ビジネス英語）コンテンツストック テーブル設計
-- 対象: Supabase (PostgreSQL)
-- 作成日: 2026-07-13
-- ============================================================

-- ------------------------------------------------------------
-- 拡張機能（gen_random_uuid()に必要。Supabaseでは通常デフォルト有効）
-- ------------------------------------------------------------
create extension if not exists pgcrypto;

-- ------------------------------------------------------------
-- コード自動採番用シーケンス（EX-0001, EX-0002 ... の形式）
-- ------------------------------------------------------------
create sequence if not exists public.expressions_code_seq
  start 1
  increment 1;

-- ------------------------------------------------------------
-- 本体テーブル
-- ------------------------------------------------------------
create table if not exists public.expressions (
  -- 内部ID（結合・参照用）
  id                    uuid primary key default gen_random_uuid(),

  -- 表示用コード（EX-0001 形式、自動採番）
  code                  text not null unique
                        default ('EX-' || lpad(nextval('public.expressions_code_seq')::text, 4, '0')),

  -- カテゴリ：拡張軸。制約はあえて緩め（CHECKなし）にして、新カテゴリ追加時にマイグレーション不要にしている
  -- 2026-08-15: 当初想定していた「TOEIC表現」という別カテゴリは廃止し、通常の表現プールに
  -- exam_tagsで横断タグを付ける方式に統一した（TOEICはあくまで既存表現の頻出度タグであり、
  -- フィールド構成が同じコンテンツを別カテゴリに分ける必要はないと判断）。
  category              text not null default '表現',

  -- シーンタグ（複数選択可）
  scene_tags            text[] not null,

  -- フォーマル度（カジュアル〜フォーマルにまたがる表現もあるため配列）
  formality             text[] not null,

  -- 難易度（単一選択）
  level                 text not null,

  -- 機能・意図タグ（複数選択可、任意）。フレーズが「何をするための表現か」を表す軸で、
  -- scene_tagsとは独立。全表現に必ず付くわけではない（該当なしはNULL）。
  -- Pro限定の「シーン×機能」絞り込みに使用。
  intent_tags           text[],

  -- 表現本体
  expression_en         text not null,
  meaning_ja            text not null,

  -- 例文（最大2つ。3つ目以降が必要になったらJSONB化を検討）
  example_1_en          text,
  example_1_ja          text,
  example_2_en          text,
  example_2_ja          text,

  -- 類似・言い換え表現（複数）
  similar_expressions   text[],

  -- 資格試験の頻出タグ（例: ['TOEIC']）。categoryとは独立した横断タグ。
  -- CHECK制約はあえて付けない（将来「英検」などを追加してもマイグレーション不要にするため）。
  exam_tags              text[],

  -- 使用上の注意（誤用・NG例・地域差など）
  usage_notes           text,

  -- 検証ステータス
  verification_status   text not null default 'AI生成のみ',

  -- Shorts/TTS用の音声メモ（誰が話すか・トーンなど。台本そのものではなく素材）
  audio_memo            text,

  -- Pro/Premium限定表現かどうか。Shorts動画で取り上げたフレーズなど、
  -- 「意味が気になる」フックが効く表現をtrueにする運用を想定。
  -- true時、フレーズ本体（expression_en）はFreeユーザーにも見せるが、
  -- 意味・例文・類似表現・使用上の注意はアプリ側でマスクする（ページ側のゲーティング処理）。
  is_premium             boolean not null default false,

  -- 例文音声（Pro/Premium限定機能）。Supabase Storageの非公開バケット
  -- "expression-audio" 内のパスを保持する。nullは未生成。
  -- アプリ側は生パスをクライアントに渡さず、署名付きURLをAPI経由で発行する。
  audio_expression_path  text,
  audio_example_1_path   text,
  audio_example_2_path   text,

  -- 公開ステータス
  publish_status        text not null default '下書き',

  -- タイムスタンプ
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),

  -- ---------------- 値の整合性チェック ----------------
  constraint chk_scene_tags_valid check (
    -- '買い物','外食','旅行','友人','体調' はスピーキング・ロードマップのStage1〜3向け
    -- 日常会話タグ（2026-09-09追加）。それ以外はビジネス文脈。
    scene_tags <@ array['会議','雑談','メール','電話','プレゼン','依頼・断り','交渉','買い物','外食','旅行','友人','体調']::text[]
    and array_length(scene_tags, 1) >= 1
  ),
  constraint chk_formality_valid check (
    formality <@ array['カジュアル','ミドル','フォーマル']::text[]
    and array_length(formality, 1) >= 1
  ),
  constraint chk_level_valid check (
    level in ('初級','中級','上級')
  ),
  constraint chk_intent_tags_valid check (
    intent_tags is null
    or intent_tags <@ array['依頼','断り・保留','提案','同意・肯定','反論・懸念','謝罪','確認','相槌・共感']::text[]
  ),
  constraint chk_verification_status_valid check (
    verification_status in ('AI生成のみ','クロスチェック済み','ネイティブ確認済み')
  ),
  constraint chk_publish_status_valid check (
    publish_status in ('下書き','公開')
  )
);

comment on table public.expressions is '英語アプリ（表現×ビジネス英語）のコンテンツストック。1行=1表現。';
comment on column public.expressions.category is '拡張軸。現状は「表現」のみ運用（TOEICはexam_tagsで横断タグ付けする方式に統一）。';
comment on column public.expressions.exam_tags is '資格試験の頻出タグ（例: TOEIC）。categoryとは独立した横断タグ。将来英検などを追加してもCHECK変更不要。';
comment on column public.expressions.audio_memo is 'Shorts制作用の素材メモ（誰が話すか・トーン等）。完成台本ではない。';

-- ------------------------------------------------------------
-- updated_at 自動更新トリガー
-- ------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_expressions_updated_at on public.expressions;
create trigger trg_expressions_updated_at
  before update on public.expressions
  for each row execute function public.set_updated_at();

-- ------------------------------------------------------------
-- インデックス
-- ------------------------------------------------------------
-- タグでの絞り込み（複数選択）を高速化
create index if not exists idx_expressions_scene_tags on public.expressions using gin (scene_tags);
create index if not exists idx_expressions_formality   on public.expressions using gin (formality);
create index if not exists idx_expressions_intent_tags on public.expressions using gin (intent_tags);
create index if not exists idx_expressions_exam_tags   on public.expressions using gin (exam_tags);

-- 公開済みコンテンツの一覧表示を高速化
create index if not exists idx_expressions_published
  on public.expressions (level)
  where publish_status = '公開';

-- ------------------------------------------------------------
-- RLS（行レベルセキュリティ）
-- 運用方針：コンテンツの作成・編集は開発者側（service_role経由）のみ。
-- アプリの一般ユーザーは「公開済み」の行だけ閲覧できる。
-- ------------------------------------------------------------
alter table public.expressions enable row level security;

drop policy if exists "公開済みコンテンツは誰でも閲覧可" on public.expressions;
create policy "公開済みコンテンツは誰でも閲覧可"
  on public.expressions
  for select
  to anon, authenticated
  using (publish_status = '公開');

-- insert/update/delete のポリシーは意図的に作成しない
-- → anon/authenticatedキーからの書き込みは一切不可
-- → コンテンツ投入・編集は service_role キー（管理側）からのみ行う

-- ============================================================
-- 使い方メモ
-- ============================================================
-- ・シーンタグ検索例:
--   select * from public.expressions
--   where scene_tags && array['会議']::text[] and publish_status = '公開';
--
-- ・フォーマル度検索例:
--   select * from public.expressions
--   where formality && array['カジュアル']::text[] and publish_status = '公開';
--
-- ・資格試験タグ検索例（TOEIC頻出の表現のみ）:
--   select * from public.expressions
--   where exam_tags && array['TOEIC']::text[] and publish_status = '公開';
--
-- ・フィールド構成が既存の表現と同じ横断的なくくり（例: TOEIC頻出）を増やす場合は
--   exam_tagsのような「タグ列」を追加する（categoryは分けない）。
--   カテゴリを分けるのは、持たせたい項目自体が大きく異なる場合のみにする。
--   → 実例: 単語学習機能（間隔反復・小テスト）は vocabulary_schema.sql として
--     別テーブルで実装した（表現とは持たせたい項目が大きく異なるため）。
-- ============================================================
