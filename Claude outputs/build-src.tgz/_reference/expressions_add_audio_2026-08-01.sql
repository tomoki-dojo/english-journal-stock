-- ============================================================
-- 例文音声再生機能（Pro/Premium限定）の土台追加
-- Supabase SQL Editorで実行。何度実行しても安全。
-- ============================================================

alter table public.expressions
  add column if not exists audio_expression_path text,
  add column if not exists audio_example_1_path text,
  add column if not exists audio_example_2_path text;

comment on column public.expressions.audio_expression_path is
  '例文音声（フレーズ本体）。Storage "expression-audio" バケット内のパス。生パスはクライアントに渡さず、署名付きURLはAPI経由でのみ発行する。';

-- 非公開のStorageバケットを作成（既にあればスキップ）。
-- アプリはservice_roleからsigned URLを都度発行して配信するため、
-- バケット自体はpublic=falseのままでよい。
insert into storage.buckets (id, name, public)
values ('expression-audio', 'expression-audio', false)
on conflict (id) do nothing;

-- 確認用: 音声が入っている表現の一覧
-- select code, expression_en, audio_expression_path from public.expressions
-- where audio_expression_path is not null order by code;
