-- ============================================================
-- 単語帳のお気に入り（マイリスト）テーブル設計
-- 対象: Supabase (PostgreSQL)
-- saved_expressions_schema.sqlと同じ設計方針。
-- 「保存（ブックマーク）」はFree/Pro問わず誰でもできる汎用機能。
-- 「学習開始」（word_review_progressへの追加、Pro限定・間隔反復の対象にする）とは独立した概念。
-- 学習を始めると自動的にここにも保存される（addToLearningList内でupsertする）。
-- ============================================================

create table if not exists public.saved_vocabulary (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references auth.users(id) on delete cascade,
  vocabulary_id uuid not null references public.vocabulary(id) on delete cascade,
  created_at    timestamptz not null default now(),

  unique (user_id, vocabulary_id)
);

comment on table public.saved_vocabulary is
  '単語帳のお気に入り（マイリスト）。件数上限はアプリ側（Freeプランのみ）で制御する。学習リスト（word_review_progress）とは独立。';

create index if not exists idx_saved_vocabulary_user on public.saved_vocabulary(user_id);

-- ------------------------------------------------------------
-- RLS
-- 運用方針：本人の行だけ読み書き可能。それ以外はservice_role経由のみ。
-- ------------------------------------------------------------
alter table public.saved_vocabulary enable row level security;

drop policy if exists "本人の保存分のみ閲覧可" on public.saved_vocabulary;
create policy "本人の保存分のみ閲覧可"
  on public.saved_vocabulary
  for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "本人のみ保存可" on public.saved_vocabulary;
create policy "本人のみ保存可"
  on public.saved_vocabulary
  for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "本人のみ削除可" on public.saved_vocabulary;
create policy "本人のみ削除可"
  on public.saved_vocabulary
  for delete
  to authenticated
  using (auth.uid() = user_id);
