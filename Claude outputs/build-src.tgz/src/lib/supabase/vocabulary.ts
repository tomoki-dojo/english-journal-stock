// src/lib/supabase/vocabulary.ts
// 単語学習機能のコンテンツ取得。expressions.tsと同じ考え方で、
// 閲覧・保存（マイリスト）・ランダム学習は未ログインでも/Freeでも全員可能（保存はログイン必須）。
// Pro限定は「学習を始めて間隔反復（今日の復習）を行う」機能面のみ。
import { supabaseAdmin } from "@/lib/supabase/server";
import { VOCABULARY_PAGE_SIZE } from "@/lib/pagination-constants";
import type {
  PartOfSpeech,
  VocabLevel,
  VocabVerificationStatus,
  Vocabulary,
} from "@/components/vocabulary/types";

const LIST_LIMIT = 1000;

type DbVocabularyRow = {
  id: string;
  code: string;
  category: string;
  word_en: string;
  part_of_speech: string;
  meaning_ja: string;
  example_en: string | null;
  example_ja: string | null;
  synonyms: string[] | null;
  business_field: string[] | null;
  exam_tags: string[] | null;
  level: string;
  usage_notes: string | null;
  verification_status: string;
  publish_status: string;
  created_at: string;
};

function fromDbRow(row: DbVocabularyRow): Vocabulary {
  return {
    id: row.id,
    code: row.code,
    category: row.category,
    wordEn: row.word_en,
    partOfSpeech: row.part_of_speech as PartOfSpeech,
    meaningJa: row.meaning_ja,
    exampleEn: row.example_en ?? undefined,
    exampleJa: row.example_ja ?? undefined,
    synonyms: row.synonyms ?? undefined,
    businessField: row.business_field ?? undefined,
    examTags: row.exam_tags ?? undefined,
    level: row.level as VocabLevel,
    usageNotes: row.usage_notes ?? undefined,
    verificationStatus: row.verification_status as VocabVerificationStatus,
    publishStatus: row.publish_status,
    createdAt: row.created_at,
  };
}

// 公開済み単語の一覧取得（新しい順）。TOEIC頻出の単語もexam_tagsが付いた状態でここに含まれる
// （単語帳・表現一覧に吸収する設計に伴い、category絞り込み専用の取得関数は廃止した）。
export async function listPublishedVocabulary(): Promise<Vocabulary[]> {
  const { data, error } = await supabaseAdmin
    .from("vocabulary")
    .select()
    .eq("publish_status", "公開")
    .order("created_at", { ascending: false })
    .limit(LIST_LIMIT);

  if (error) {
    throw new Error(`単語一覧の取得に失敗しました: ${error.message}`);
  }

  return (data as DbVocabularyRow[]).map(fromDbRow);
}

type DbVocabularySearchRow = DbVocabularyRow & { total_count: number };

export type VocabularySearchParams = {
  keyword?: string;
  level?: string;
  examTag?: string;
  page?: number;
  pageSize?: number;
};

export type VocabularySearchResult = {
  items: Vocabulary[];
  totalCount: number;
  page: number;
  pageSize: number;
};

// 単語帳一覧（/vocabulary, /library）用のサーバー側検索・ページネーション。
// キーワード・レベル・資格試験タグはDB関数 search_vocabulary 側でバインドパラメータとして扱うため、
// カンマ・括弧などの記号を含む検索語を渡しても安全（PostgRESTのor()文字列組み立てを避けている）。
export async function searchPublishedVocabulary(
  params: VocabularySearchParams = {}
): Promise<VocabularySearchResult> {
  const page = Math.max(1, params.page ?? 1);
  const pageSize = params.pageSize ?? VOCABULARY_PAGE_SIZE;
  const offset = (page - 1) * pageSize;

  const { data, error } = await supabaseAdmin.rpc("search_vocabulary", {
    p_keyword: params.keyword?.trim() || null,
    p_level: params.level || null,
    p_exam_tag: params.examTag || null,
    p_limit: pageSize,
    p_offset: offset,
  });

  if (error) {
    throw new Error(`単語検索に失敗しました: ${error.message}`);
  }

  const rows = (data ?? []) as DbVocabularySearchRow[];
  const totalCount = rows[0]?.total_count ?? 0;

  return {
    items: rows.map(fromDbRow),
    totalCount,
    page,
    pageSize,
  };
}

// ホーム画面などで「◯語収録」とさりげなく出すための軽量カウント取得（行データは取らない）。
export async function getPublishedVocabularyCount(): Promise<number> {
  const { count, error } = await supabaseAdmin
    .from("vocabulary")
    .select("id", { count: "exact", head: true })
    .eq("publish_status", "公開");

  if (error) {
    throw new Error(`単語件数の取得に失敗しました: ${error.message}`);
  }

  return count ?? 0;
}

// 学習リスト・出題の誤答生成用：指定したid群の単語を取得
export async function listVocabularyByIds(ids: string[]): Promise<Vocabulary[]> {
  if (ids.length === 0) return [];

  const { data, error } = await supabaseAdmin.from("vocabulary").select().in("id", ids);

  if (error) {
    throw new Error(`単語の取得に失敗しました: ${error.message}`);
  }

  return (data as DbVocabularyRow[]).map(fromDbRow);
}
