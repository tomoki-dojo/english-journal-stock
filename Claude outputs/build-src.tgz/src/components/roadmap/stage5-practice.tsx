"use client";

import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Crown, Mic, PartyPopper, RotateCcw, Square, User2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { TappableText } from "./tappable-text";
import { RoundHeader, UsageBonusBadge } from "./round-header";
import { GrowthBadge } from "./growth-badge";
import { STAGE_COLORS, withAlpha } from "./stage-colors";
import { ARTHUR_NAME, ArthurAvatar } from "./arthur";
import { useSpeechRecognition } from "@/lib/use-speech-recognition";
import { useBgmDuck } from "./roadmap-sound";
import {
  STAGE5_TURN_COUNT,
  type Stage5Scenario,
  type Stage5ScenarioListItem,
  type Stage5Track,
  type Stage5Turn,
  type Stage5TurnResult,
  type Stage5UsageInfo,
  welcomeBonusLabel,
  STAGE5_PRO_DAILY_LIMIT,
} from "./types";

type ViewState = "loading" | "picker" | "chat" | "limit_exceeded" | "not_ready" | "error";
type AnswerPhase = "prompt" | "review" | "sending";

const STAGE_COLOR = STAGE_COLORS[5];

type Stage5PracticeProps = {
  track: Stage5Track;
};

// Stage5（上級ロールプレイ）の練習画面。Stage4Practiceとほぼ同じ構造だが、track（daily/business）
// でシナリオ一覧・利用回数・解放判定がすべてスコープされる点だけが違う
// （_reference/speaking-roadmap-design.md「Stage5：スキーマ・解放ロジック設計」参照）。
export function Stage5Practice({ track }: Stage5PracticeProps) {
  const [state, setState] = useState<ViewState>("loading");
  const [scenarios, setScenarios] = useState<Stage5ScenarioListItem[]>([]);
  const [usage, setUsage] = useState<Stage5UsageInfo | null>(null);
  const [limit, setLimit] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [notReadyMessage, setNotReadyMessage] = useState("");

  const [activeScenario, setActiveScenario] = useState<Stage5Scenario | null>(null);
  const [history, setHistory] = useState<Stage5Turn[]>([]);
  const [turnIndex, setTurnIndex] = useState(1);
  const [answerPhase, setAnswerPhase] = useState<AnswerPhase>("prompt");
  const [manualText, setManualText] = useState("");
  const [sessionResult, setSessionResult] = useState<Stage5TurnResult | null>(null);

  const speech = useSpeechRecognition({ continuous: true });
  useBgmDuck(speech.status === "listening");
  const trackLabel = track === "daily" ? "日常編" : "ビジネス編";

  async function loadScenarios() {
    setState("loading");
    setError(null);
    try {
      const res = await fetch(`/api/roadmap/stage5/scenarios?track=${track}`, { cache: "no-store" });
      const json = await res.json();
      if (!res.ok) {
        if (res.status === 403) {
          setNotReadyMessage(json.error ?? "");
          setState("not_ready");
          return;
        }
        throw new Error(json.error ?? "シナリオ一覧の取得に失敗しました");
      }
      setScenarios(json.scenarios as Stage5ScenarioListItem[]);
      setUsage(json.usage as Stage5UsageInfo);
      setState("picker");
    } catch (err) {
      setError(err instanceof Error ? err.message : "シナリオ一覧の取得に失敗しました");
      setState("error");
    }
  }

  useEffect(() => {
    loadScenarios();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [track]);

  useEffect(() => {
    if (speech.status === "idle" && speech.transcript && answerPhase === "prompt") {
      setManualText(speech.transcript);
      setAnswerPhase("review");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [speech.status, speech.transcript]);

  function startScenario(scenario: Stage5ScenarioListItem) {
    setActiveScenario(scenario);
    setHistory([{ role: "ai", text: scenario.openingLineEn }]);
    setTurnIndex(1);
    setSessionResult(null);
    setAnswerPhase("prompt");
    setManualText("");
    speech.reset();
    setState("chat");
  }

  function backToPicker() {
    setActiveScenario(null);
    setSessionResult(null);
    loadScenarios();
  }

  function retrySpeaking() {
    setManualText("");
    speech.reset();
    setAnswerPhase("prompt");
    // 言い直しは、もう一度マイクをタップさせずにそのまま聞き取りへ入る
    if (speech.status !== "unsupported") speech.start();
  }

  async function submitTurn() {
    if (!activeScenario || manualText.trim().length === 0) return;
    setAnswerPhase("sending");
    setError(null);

    try {
      const res = await fetch("/api/roadmap/stage5/turn", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          scenarioId: activeScenario.id,
          turnIndex,
          history,
          userUtterance: manualText.trim(),
        }),
      });
      const json = await res.json();

      if (!res.ok) {
        if (res.status === 429) {
          setLimit(json.limit ?? 0);
          setState("limit_exceeded");
          return;
        }
        throw new Error(json.error ?? "会話処理に失敗しました");
      }

      const result = json as Stage5TurnResult;
      const nextHistory: Stage5Turn[] = [
        ...history,
        { role: "user", text: manualText.trim() },
        { role: "ai", text: result.aiReplyEn },
      ];
      setHistory(nextHistory);
      setUsage(result.usage);

      if (result.sessionComplete) {
        setSessionResult(result);
      } else {
        setTurnIndex((i) => i + 1);
        setManualText("");
        speech.reset();
        setAnswerPhase("prompt");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "会話処理に失敗しました");
      setAnswerPhase("review");
    }
  }

  if (state === "loading") {
    return <p className="text-sm text-zinc-400">読み込み中...</p>;
  }

  if (state === "error") {
    return <p className="text-sm text-red-600">{error ?? "エラーが発生しました"}</p>;
  }

  if (state === "not_ready") {
    return (
      <div className="rounded-xl border border-dashed border-zinc-200 bg-zinc-100/30 px-6 py-10 text-center">
        <p className="text-sm text-zinc-500">{notReadyMessage || `Stage5${trackLabel}はまだ解放されていません。`}</p>
        <Link
          href="/roadmap/stage4"
          className="mt-4 inline-flex items-center gap-1 rounded-lg border border-zinc-300 bg-white px-4 py-2 text-sm font-medium text-zinc-700 transition-colors hover:border-zinc-400"
        >
          Stage4に進む
        </Link>
      </div>
    );
  }

  if (state === "limit_exceeded") {
    return (
      <div className="rounded-xl border border-dashed border-zinc-200 bg-zinc-100/30 px-6 py-10 text-center">
        <p className="text-sm text-zinc-700">今日のセッションは{limit}回まで使い切りました。</p>
        <p className="mt-1 text-xs text-zinc-400">また明日挑戦できます。<TrackOnMount event="ai_limit_hit" params={{ stage: 5 }} onceKey={`ai_limit_hit:stage5:${new Date().toDateString()}`} /><Link href="/roadmap/pro?from=stage5" className="font-semibold text-amber-600 underline underline-offset-2">Proにすると上限が大きく緩和されます。</Link></p>
        <Link
          href="/roadmap"
          className="mt-4 inline-flex items-center gap-1 rounded-lg border border-zinc-300 bg-white px-4 py-2 text-sm font-medium text-zinc-700 transition-colors hover:border-zinc-400"
        >
          部屋に戻る
        </Link>
      </div>
    );
  }

  if (state === "picker") {
    const usageLabel = usage ? `今日のセッション あと${usage.remaining}回` : "";
    return (
      <div>
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm font-medium text-zinc-700">話すシーンを選んでください（{trackLabel}）</p>
          {usageLabel && (
            <span className="text-xs text-zinc-400">
              {usageLabel}
              {welcomeBonusLabel(usage) && <UsageBonusBadge label={welcomeBonusLabel(usage)} />}
            </span>
          )}
        </div>
        {usage && usage.remaining <= 0 && usage.limit < STAGE5_PRO_DAILY_LIMIT && (
          <>
          <TrackOnMount event="ai_limit_hit" params={{ stage: 5 }} onceKey={`ai_limit_hit:stage5:${new Date().toDateString()}`} />
          <Link
            href="/roadmap/pro?from=stage5"
            className="mb-4 flex items-center justify-center gap-1.5 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-700 transition-colors hover:bg-amber-100"
          >
            <Crown className="h-4 w-4" />
            Proで1日{STAGE5_PRO_DAILY_LIMIT}回まで話せる
          </Link>
          </>
        )}

        {scenarios.length === 0 ? (
          <p className="text-sm text-zinc-400">現在、選べるシナリオがありません。</p>
        ) : (
          <div className="flex flex-col gap-3">
            {scenarios.map((scenario) => {
              const disabled = usage ? usage.remaining <= 0 : false;
              return (
                <button
                  key={scenario.id}
                  type="button"
                  disabled={disabled}
                  onClick={() => startScenario(scenario)}
                  className="flex items-start gap-3 rounded-xl border border-zinc-200 bg-zinc-100/50 p-4 text-left transition-colors hover:border-accent/50 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <GrowthBadge stage={5} warmth={scenario.warmth} />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-zinc-900">{scenario.titleJa}</p>
                      <span className="rounded-full bg-zinc-200/70 px-2 py-0.5 text-[10px] font-medium text-zinc-500">
                        {scenario.sceneTag}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-zinc-500">{scenario.situationJa}</p>
                    {scenario.status === "習得済み" && (
                      <p className="mt-1.5 text-xs font-medium" style={{ color: STAGE_COLOR }}>
                        話せるようになりました
                      </p>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  if (!activeScenario) {
    return <p className="text-sm text-zinc-400">読み込み中...</p>;
  }

  if (sessionResult) {
    return (
      <div>
        <RoundHeader
          stage={5}
          subFormatLabel={activeScenario.titleJa}
          usageLabel={usage ? `今日のセッション あと${usage.remaining}回` : ""}
          usageBonusLabel={welcomeBonusLabel(usage)}
          arthurMood={sessionResult.overallPass ? "happy" : "sad"}
        />
        <div className="rounded-xl border border-zinc-200 bg-zinc-100/50 p-6 text-center">
          <PartyPopper className="mx-auto mb-3 h-6 w-6" style={{ color: sessionResult.overallPass ? STAGE_COLOR : "#a1a1aa" }} />
          <p className="text-sm font-medium text-zinc-800">
            {sessionResult.overallPass ? "会話を通じてゴールを達成できました" : "もう少しでゴール達成です"}
          </p>
          <p className="mt-2 text-sm text-zinc-600">{sessionResult.feedbackJa}</p>

          {sessionResult.graduated && (
            <div className="mt-4 flex items-center justify-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
              <PartyPopper className="h-4 w-4" />
              このシナリオ、話せるようになりました
            </div>
          )}

          <div className="mt-5 flex gap-3">
            <button
              type="button"
              onClick={() => startScenario({ ...activeScenario, track, status: "練習中", warmth: 0 })}
              style={{ backgroundColor: STAGE_COLOR }}
              className="flex flex-1 items-center justify-center gap-1 sm:gap-1.5 rounded-lg px-2 py-2 text-xs sm:px-4 sm:py-2.5 sm:text-sm font-semibold text-white transition-all duration-150 hover:opacity-90 active:scale-[.97]"
            >
              もう一度話す
            </button>
            <button
              type="button"
              onClick={backToPicker}
              className="flex items-center justify-center gap-1 sm:gap-1.5 rounded-lg border border-zinc-300 bg-white px-2 py-2 text-xs sm:px-4 sm:py-2.5 sm:text-sm font-medium text-zinc-600 transition-all duration-150 hover:border-zinc-400 active:scale-[.97]"
            >
              シーン一覧に戻る
            </button>
          </div>
        </div>
      </div>
    );
  }

  const usageLabel = usage ? `今日のセッション あと${usage.remaining}回` : "";

  return (
    <div>
      <RoundHeader
        stage={5}
        subFormatLabel={activeScenario.titleJa}
        usageLabel={usageLabel}
        usageBonusLabel={welcomeBonusLabel(usage)}
      />

      <div
        className="mb-3 rounded-xl border p-4"
        style={{ borderColor: withAlpha(STAGE_COLOR, "40"), backgroundColor: withAlpha(STAGE_COLOR, "0d") }}
      >
        <p className="text-xs text-zinc-500">{activeScenario.situationJa}</p>
        <p className="mt-1 text-xs font-medium text-zinc-600">ゴール：{activeScenario.goalJa}</p>
      </div>

      {history.length > 0 && history[history.length - 1].role === "ai" && (
        <div className="mb-3 flex items-start gap-3 rounded-xl border border-zinc-200 bg-white p-4 shadow-sm">
          <ArthurAvatar size={44} animated mood="talk" talkKey={history.length - 1} />
          <div className="flex-1">
            <p className="mb-0.5 text-xs font-semibold" style={{ color: STAGE_COLOR }}>
              {ARTHUR_NAME}
            </p>
            <TappableText
              text={history[history.length - 1].text}
              accentColor={STAGE_COLOR}
              className="text-2xl font-bold leading-snug text-zinc-900"
            />
          </div>
        </div>
      )}

      <p className="mb-2 text-center text-xs text-zinc-400">
        {turnIndex}/{STAGE5_TURN_COUNT}ターン目
      </p>

      <div className="mb-3 rounded-xl border border-zinc-200 bg-zinc-100/50 p-4">
        {answerPhase === "prompt" && (
          <div className="text-center">
            {speech.status === "unsupported" ? (
              <div>
                <p className="mb-2 text-xs text-zinc-400">
                  お使いのブラウザは音声入力に対応していないため、テキストで入力してください。
                </p>
                <textarea
                  value={manualText}
                  onChange={(e) => setManualText(e.target.value)}
                  placeholder="声に出す代わりに、ここに英文を入力"
                  rows={2}
                  className="w-full rounded-lg border border-zinc-300 px-3 py-2 text-base text-zinc-900 focus:border-zinc-400 focus:outline-none"
                />
                <button
                  type="button"
                  disabled={manualText.trim().length === 0}
                  onClick={() => setAnswerPhase("review")}
                  style={{ backgroundColor: STAGE_COLOR }}
                  className="mt-3 flex w-full items-center justify-center gap-1 sm:gap-1.5 rounded-lg px-2 py-2 text-xs sm:px-4 sm:py-2.5 sm:text-sm font-semibold text-white transition-all duration-150 hover:opacity-90 active:scale-[.97] disabled:opacity-50"
                >
                  この内容で進む
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={speech.status === "listening" ? speech.stop : speech.start}
                style={{ backgroundColor: speech.status === "listening" ? "#dc2626" : STAGE_COLOR }}
                className="mx-auto flex h-16 w-16 items-center justify-center rounded-full text-white shadow-md transition-all duration-150 hover:opacity-90 active:scale-95"
              >
                {speech.status === "listening" ? <Square className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
              </button>
            )}
            <p className="mt-3 text-xs text-zinc-400">
              {speech.status === "listening" ? "聞き取り中...もう一度タップで終了" : "タップして声に出す"}
            </p>
            {speech.status === "listening" && speech.liveText && (
              <p className="mt-3 rounded-lg bg-white px-3 py-2 text-left text-sm text-zinc-700">{speech.liveText}</p>
            )}
            {speech.errorMessage && <p className="mt-2 text-xs text-red-600">{speech.errorMessage}</p>}
          </div>
        )}

        {(answerPhase === "review" || answerPhase === "sending") && (
          <div className="animate-question-card-enter">
            <p className="mb-1.5 text-xs text-zinc-400">この内容で送ります（間違っていれば修正できます）</p>
            <textarea
              value={manualText}
              onChange={(e) => setManualText(e.target.value)}
              disabled={answerPhase === "sending"}
              rows={2}
              className="w-full rounded-lg border border-zinc-300 px-3 py-2 text-base text-zinc-900 focus:border-zinc-400 focus:outline-none disabled:opacity-60"
            />
            <div className="mt-3 flex gap-3">
              <button
                type="button"
                disabled={answerPhase === "sending" || manualText.trim().length === 0}
                onClick={submitTurn}
                style={{ backgroundColor: STAGE_COLOR }}
                className="flex flex-1 items-center justify-center gap-1 sm:gap-1.5 rounded-lg px-2 py-2 text-xs sm:px-4 sm:py-2.5 sm:text-sm font-semibold text-white transition-all duration-150 hover:opacity-90 active:scale-[.97] disabled:opacity-50"
              >
                {answerPhase === "sending" ? "送信中..." : "送る"}
              </button>
              <button
                type="button"
                disabled={answerPhase === "sending"}
                onClick={retrySpeaking}
                className="flex items-center justify-center gap-1 sm:gap-1.5 rounded-lg border border-zinc-300 bg-white px-2 py-2 text-xs sm:px-4 sm:py-2.5 sm:text-sm font-medium text-zinc-600 transition-all duration-150 hover:border-zinc-400 active:scale-[.97] disabled:opacity-50"
              >
                <RotateCcw className="h-4 w-4" />
                言い直す
              </button>
            </div>
          </div>
        )}

        {error && <p className="mt-3 text-xs text-red-600">{error}</p>}
      </div>
      <div className="mb-3 flex flex-col gap-2 rounded-xl border border-zinc-200 bg-white p-4">
        {history.map((turn, i) => (
          <div key={i} className={cn("flex items-start gap-2", turn.role === "user" && "flex-row-reverse")}>
            {turn.role === "ai" ? (
              <ArthurAvatar
                size={36}
                animated={i === history.length - 1}
                mood={i === history.length - 1 ? "talk" : "idle"}
                talkKey={i}
              />
            ) : (
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-zinc-200 text-zinc-600">
                <User2 className="h-3.5 w-3.5" />
              </div>
            )}
            <div
              className={cn(
                "max-w-[80%] rounded-lg px-3 py-1.5 text-sm",
                turn.role === "ai" ? "bg-zinc-100 text-zinc-800" : "text-white"
              )}
              style={turn.role === "user" ? { backgroundColor: STAGE_COLOR } : undefined}
            >
              {turn.role === "ai" && (
                <p className="mb-0.5 text-[10px] font-semibold" style={{ color: STAGE_COLOR }}>
                  {ARTHUR_NAME}
                </p>
              )}
              {turn.role === "ai" ? (
                <TappableText text={turn.text} accentColor={STAGE_COLOR} />
              ) : (
                turn.text
              )}
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}
