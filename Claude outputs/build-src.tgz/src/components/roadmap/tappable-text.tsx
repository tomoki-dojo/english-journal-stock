"use client";

import { useRef, useState } from "react";
import { Flag, X } from "lucide-react";
import { cn } from "@/lib/utils";

type Sense = { pos: string | null; meaning: string; others: string[]; note: string | null };
type Entry = { wordId: string; flagged: boolean; word: string; lemma: string | null; senses: Sense[] };
type LookupState = { status: "loading" } | { status: "done"; entry: Entry | null } | { status: "error" };

// 同じ単語を何度もタップしても通信しないよう、モジュール内でキャッシュする（苦手の入れ外しも反映する）。
const cache = new Map<string, Entry | null>();

const TOKEN_RE = /([A-Za-z]+(?:['’-][A-Za-z]+)*)/;

// 英文の単語をタップすると、単語ノートの辞書から意味を出す（Stage4/5のAI発言用）。
export function TappableText({
  text,
  accentColor,
  className,
}: {
  text: string;
  accentColor: string;
  className?: string;
}) {
  const [selected, setSelected] = useState<{ index: number; word: string } | null>(null);
  const [lookup, setLookup] = useState<LookupState | null>(null);

  const currentIndex = useRef<number | null>(null);

  const select = async (index: number, word: string) => {
    if (selected?.index === index) {
      close();
      return;
    }
    currentIndex.current = index;
    setSelected({ index, word });
    const key = word.toLowerCase();
    if (cache.has(key)) {
      setLookup({ status: "done", entry: cache.get(key) ?? null });
      return;
    }
    setLookup({ status: "loading" });
    try {
      const res = await fetch(`/api/roadmap/word-lookup?w=${encodeURIComponent(word)}`);
      if (!res.ok) throw new Error("lookup failed");
      const json = (await res.json()) as { entry: Entry | null };
      cache.set(key, json.entry);
      // 取得中に別の単語へ切り替えられていたら、結果は捨てる
      if (currentIndex.current === index) setLookup({ status: "done", entry: json.entry });
    } catch {
      if (currentIndex.current === index) setLookup({ status: "error" });
    }
  };

  const [saving, setSaving] = useState(false);

  const toggleFlag = async (entry: Entry, cacheKey: string) => {
    if (saving) return;
    setSaving(true);
    const next = !entry.flagged;
    try {
      const res = await fetch("/api/roadmap/weak-words", {
        method: next ? "POST" : "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ wordId: entry.wordId }),
      });
      if (!res.ok) throw new Error("toggle failed");
      const updated = { ...entry, flagged: next };
      cache.set(cacheKey, updated);
      setLookup({ status: "done", entry: updated });
    } catch {
      setLookup({ status: "error" });
    } finally {
      setSaving(false);
    }
  };

  function close() {
    currentIndex.current = null;
    setSelected(null);
    setLookup(null);
  }

  const parts = text.split(TOKEN_RE);

  return (
    <>
      <p className={className}>
        {parts.map((part, i) =>
          i % 2 === 1 ? (
            <span
              key={i}
              role="button"
              tabIndex={0}
              onClick={() => select(i, part)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  select(i, part);
                }
              }}
              className={cn(
                "cursor-pointer rounded-sm transition-colors hover:bg-amber-100",
                selected?.index === i && "bg-amber-200"
              )}
            >
              {part}
            </span>
          ) : (
            part
          )
        )}
      </p>
      {selected && lookup && (
        <div
          className="mt-2 rounded-lg border bg-white p-2.5 text-left text-sm font-normal text-zinc-800 shadow-sm sm:p-3"
          style={{ borderColor: accentColor }}
        >
          <div className="flex items-start justify-between gap-2">
            <p className="font-semibold text-zinc-900">
              {lookup.status === "done" && lookup.entry ? lookup.entry.word : selected.word}
              {lookup.status === "done" && lookup.entry?.lemma && (
                <span className="ml-1.5 text-xs font-normal text-zinc-400">{selected.word}</span>
              )}
            </p>
            <button
              type="button"
              onClick={close}
              aria-label="閉じる"
              className="shrink-0 rounded p-0.5 text-zinc-400 hover:text-zinc-700"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          {lookup.status === "loading" && <p className="mt-1 text-xs text-zinc-400">...</p>}
          {lookup.status === "error" && <p className="mt-1 text-xs text-red-600">取得できませんでした</p>}
          {lookup.status === "done" && !lookup.entry && (
            <p className="mt-1 text-xs text-zinc-400">単語ノートに載っていません</p>
          )}
          {lookup.status === "done" && lookup.entry && (
            <button
              type="button"
              disabled={saving}
              onClick={() => toggleFlag(lookup.entry as Entry, selected.word.toLowerCase())}
              className={cn(
                "mt-2 inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-bold transition-colors disabled:opacity-50",
                lookup.entry.flagged
                  ? "border-red-300 bg-red-50 text-red-600"
                  : "border-zinc-300 bg-white text-zinc-600 hover:border-red-300 hover:text-red-600"
              )}
            >
              <Flag className="h-3.5 w-3.5" />
              {lookup.entry.flagged ? "苦手に入れた" : "苦手に入れる"}
            </button>
          )}
          {lookup.status === "done" &&
            lookup.entry?.senses.map((s, k) => (
              <div key={k} className="mt-1">
                <p>
                  {s.pos && <span className="mr-1.5 text-[10px] text-zinc-400">{s.pos}</span>}
                  {s.meaning}
                </p>
                {s.others.length > 0 && (
                  <p className="text-xs text-zinc-500">他：{s.others.join("、")}</p>
                )}
                {s.note && <p className="text-xs text-zinc-500">{s.note}</p>}
              </div>
            ))}
        </div>
      )}
    </>
  );
}
