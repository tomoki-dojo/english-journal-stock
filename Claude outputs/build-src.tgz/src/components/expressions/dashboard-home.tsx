"use client";

import Image from "next/image";
import Link from "next/link";
import { useMemo } from "react";
import { Check, ChevronRight, GraduationCap, Sparkles } from "lucide-react";
import { ExpressionCard } from "./expression-card";
import { ShelfItemCard } from "./shelf-item-card";
import { pickShelfItems, pickTodaysHighlight, pickTodaysScenes } from "@/lib/daily-rotation";
import { PRO_FEATURE_HIGHLIGHTS, ProFeatureLabelText } from "@/lib/pro-features";
import type { Expression } from "./types";
import type { Plan } from "@/lib/plan";

type ToeicCounts = {
  part5QuestionCount: number;
  part6PassageCount: number;
  part6QuestionCount: number;
};

type DashboardHomeProps = {
  expressions: Expression[];
  loadError?: boolean;
  plan: Plan;
  loggedIn?: boolean;
  savedExpressionIds?: string[];
  // JST基準の「今日」の日付キー（YYYY-MM-DD）。サーバー側で計算して渡すことで、
  // サーバー/クライアント間のハイドレーション不一致を避ける。
  dateKey: string;
  // TOEICカードに「◯語・◯選・◯問収録」とさりげなく出すための件数。取得失敗時はnull/0で渡ってくる。
  vocabularyCount?: number;
  toeicCounts?: ToeicCounts | null;
};

// ダッシュボードのホーム画面。
// 「今日のピックアップ」1件と、シーン別の棚（日替わりで3シーン）を表示する。
// 棚は数件のティーザー表示のみで、シーン別の全件表示は引き続き/library（Pro限定）に委ねる。
export function DashboardHome({
  expressions,
  loadError = false,
  plan,
  loggedIn = true,
  savedExpressionIds = [],
  dateKey,
  vocabularyCount = 0,
  toeicCounts = null,
}: DashboardHomeProps) {
  const savedIdSet = useMemo(() => new Set(savedExpressionIds), [savedExpressionIds]);

  const highlight = useMemo(
    () => pickTodaysHighlight(expressions, dateKey),
    [expressions, dateKey]
  );

  const shelves = useMemo(() => {
    const scenes = pickTodaysScenes(dateKey);
    return scenes
      .map((scene) => ({ scene, items: pickShelfItems(expressions, scene, dateKey) }))
      .filter((shelf) => shelf.items.length > 0);
  }, [expressions, dateKey]);

  return (
    <div className="space-y-10">
      <div className="flex items-start gap-3">
        {/* ホーム画面のマスコット装飾。タイトルの隣に添えて、案内役のような立ち位置にする */}
        <Image
          src="/mascot/bear-suit.png"
          alt=""
          width={56}
          height={56}
          priority
          className="animate-mascot-bob pointer-events-none mt-0.5 shrink-0 select-none"
        />
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-zinc-900">
            今日のビジネス英語表現
          </h1>
          <p className="mt-2 text-sm text-zinc-500">
            今日のピックアップとシーン別の表現をお届けします。全件はいつでも検索から探せます。
          </p>
        </div>
      </div>

      {loadError && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-6 py-4 text-sm text-red-700">
          表現一覧の取得に失敗しました。時間をおいて再度お試しください。
        </div>
      )}

      {highlight && (
        <section>
          <p className="mb-3 text-xs font-medium uppercase tracking-wider text-accent">
            今日のピックアップ
          </p>
          <div className="max-w-xl">
            <ExpressionCard
              expression={highlight}
              plan={plan}
              loggedIn={loggedIn}
              initialSaved={savedIdSet.has(highlight.id)}
            />
          </div>
        </section>
      )}

      {shelves.map(({ scene, items }) => (
        <section key={scene}>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-base font-semibold text-zinc-900">{scene}で使える表現</h2>
            <Link
              href={`/library?scene=${encodeURIComponent(scene)}`}
              className="flex shrink-0 items-center gap-0.5 text-xs font-medium text-zinc-500 transition-colors hover:text-accent"
            >
              すべて見る
              <ChevronRight className="h-3.5 w-3.5" />
            </Link>
          </div>
          <div className="-mx-1 flex gap-3 overflow-x-auto px-1 pb-2">
            {items.map((expression) => (
              <ShelfItemCard
                key={expression.id}
                expression={expression}
                plan={plan}
                loggedIn={loggedIn}
              />
            ))}
          </div>
        </section>
      ))}

      <section className="rounded-xl border border-zinc-200 bg-white px-6 py-6">
        <div className="mb-2 flex items-center gap-1.5">
          <GraduationCap className="h-4 w-4 text-accent" />
          <h2 className="text-sm font-semibold text-zinc-900">TOEIC対策も始めました</h2>
        </div>
        <p className="mb-1 text-sm text-zinc-500">
          TOEICのスコアだけでなく、そのまま実務でも使える単語・表現を、昇進・海外赴任要件を意識した600〜730点帯中心にまとめています。単語帳・表現一覧では「資格試験」の絞り込みからTOEIC頻出のものだけを探せます。
        </p>
        <p className="mb-4 text-xs text-zinc-400">
          単語{vocabularyCount}語・表現{expressions.length}選を収録
          {toeicCounts &&
            `、TOEIC演習はPart5${toeicCounts.part5QuestionCount}問・Part6${toeicCounts.part6PassageCount}文書${toeicCounts.part6QuestionCount}問`}
        </p>
        <div className="flex flex-wrap gap-x-4 gap-y-2">
          <Link
            href="/practice?tab=toeic"
            className="inline-flex items-center gap-0.5 text-sm font-medium text-accent hover:underline"
          >
            TOEIC演習を試す
            <ChevronRight className="h-4 w-4" />
          </Link>
          <Link
            href="/library?exam=TOEIC"
            className="inline-flex items-center gap-0.5 text-sm font-medium text-accent hover:underline"
          >
            TOEIC頻出の表現を見る
            <ChevronRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {plan === "free" && (
        <section className="rounded-xl border border-accent/20 bg-accent/5 px-6 py-6">
          <div className="mb-3 flex items-center gap-1.5">
            <Sparkles className="h-4 w-4 text-accent" />
            <h2 className="text-sm font-semibold text-zinc-900">Proの便利機能</h2>
          </div>
          <ul className="mb-4 grid gap-2 sm:grid-cols-2">
            {PRO_FEATURE_HIGHLIGHTS.map((feature) => (
              <li key={feature.label} className="flex items-center gap-2 text-sm text-zinc-600">
                <Check className="h-3.5 w-3.5 shrink-0 text-accent" />
                <ProFeatureLabelText highlight={feature} />
              </li>
            ))}
          </ul>
          <Link
            href="/settings"
            className="inline-flex items-center gap-0.5 text-sm font-medium text-accent hover:underline"
          >
            プランを見る
            <ChevronRight className="h-4 w-4" />
          </Link>
        </section>
      )}

      <div className="rounded-xl border border-dashed border-zinc-200 bg-zinc-100/30 px-6 py-8 text-center">
        <p className="mb-3 text-sm text-zinc-500">
          {expressions.length}件の表現をキーワード・レベル・フォーマル度で検索できます。
        </p>
        <Link
          href="/library"
          className="inline-flex items-center gap-1 rounded-lg bg-accent px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-accent/90"
        >
          すべての表現を見る
          <ChevronRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
