// _reference/expressions_schema.sql のCHECK制約に対応する値の定義。
// スキーマ側の値を変更したら、ここも合わせて更新すること。

export const SceneTagValues = [
  "会議",
  "雑談",
  "メール",
  "電話",
  "プレゼン",
  "依頼・断り",
  "交渉",
  // ここから下はスピーキング・ロードマップのStage1〜3向け日常会話タグ（2026-09-09追加）。
  // 上記7つは全てビジネス文脈で、日常会話に該当するタグが存在しなかったため新設した。
  "買い物",
  "外食",
  "旅行",
  "友人",
  "体調",
] as const;
export type SceneTag = (typeof SceneTagValues)[number];

export const FormalityValues = ["カジュアル", "ミドル", "フォーマル"] as const;
export type Formality = (typeof FormalityValues)[number];

export const LevelValues = ["初級", "中級", "上級"] as const;
export type Level = (typeof LevelValues)[number];

export const VerificationStatusValues = [
  "AI生成のみ",
  "クロスチェック済み",
  "ネイティブ確認済み",
] as const;
export type VerificationStatus = (typeof VerificationStatusValues)[number];

// 機能・意図タグ。フレーズが「何をするための表現か」を表す軸で、シーンとは独立。
// 全表現に必ず付くわけではない（該当なしはundefined/null）。
// Pro限定の「シーン×機能」絞り込みに使う。
export const IntentTagValues = [
  "依頼",
  "断り・保留",
  "提案",
  "同意・肯定",
  "反論・懸念",
  "謝罪",
  "確認",
  "相槌・共感",
] as const;
export type IntentTag = (typeof IntentTagValues)[number];

export type SceneTagFilter = SceneTag | "すべて";
export type FormalityFilter = Formality | "すべて";
export type LevelFilter = Level | "すべて";
export type IntentTagFilter = IntentTag | "すべて";

// 資格試験の頻出タグ。表現ストックの絞り込みUIで使う（vocabulary側にも同じ定義あり）。
export const ExamTagValues = ["TOEIC"] as const;
export type ExamTag = (typeof ExamTagValues)[number];
export type ExamTagFilter = ExamTag | "すべて";

export type Expression = {
  id: string;
  code: string;
  category: string;
  sceneTags: SceneTag[];
  formality: Formality[];
  level: Level;
  intentTags?: IntentTag[];
  expressionEn: string;
  // DB上の生の値。現在はUIでの意味・例文マスクには使っていない（未使用）。
  isPremium: boolean;
  // 旧・内容マスク機構の名残。Pro限定は機能面のみになったため常にfalse。
  locked: boolean;
  meaningJa?: string;
  example1En?: string;
  example1Ja?: string;
  example2En?: string;
  example2Ja?: string;
  similarExpressions?: string[];
  // 資格試験の頻出タグ（例: ["TOEIC"]）。category（表現）とは独立した横断タグ。
  examTags?: string[];
  usageNotes?: string;
  verificationStatus: VerificationStatus;
  audioMemo?: string;
  publishStatus: string;
  createdAt: string;
  // 例文音声（Pro/Premium限定）。生のStorageパスはクライアントに渡さず、
  // 「音声が存在するか」だけをbooleanで持つ。再生時はAPI経由で都度signed URLを取る。
  hasAudioExpression: boolean;
  hasAudioExample1: boolean;
  hasAudioExample2: boolean;
};

export type AudioField = "expression" | "example1" | "example2";

// 街の掲示板（#153）専用：スピーキング・ロードマップでこの表現に触れた進捗を
// カード上にバッジ＋「復習する」ボタンとして出すための、表示用に整形済みのデータ。
// ExpressionCard/ExpressionStockListの既存props（Expression本体）とは別に、
// 任意で渡すoptionalな追加情報として扱う（未指定なら従来通り何も表示しない）。
export type RoadmapBoardBadge = {
  label: string; // 例: "Stage1"
  mastered: boolean; // true=習得済み、false=練習中
};

// タスク#154で「復習する」はStage別の練習画面へのリンクではなく、共通の軽量復習フロー
// （ExpressionCard内でモーダルを開く）に変更したため、reviewHrefは持たない。
export type RoadmapBoardInfo = {
  badges: RoadmapBoardBadge[];
};
