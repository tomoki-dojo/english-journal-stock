import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/supabase/server-auth";
import { supabaseAdmin } from "@/lib/supabase/server";
import { lemmaCandidates } from "@/lib/word-lemma";

export const dynamic = "force-dynamic";
export const fetchCache = "force-no-store";

// タップした英単語を単語ノート(quiz_words)から引く。活用形は原形候補に直して順に探す。AIは使わない。
export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "ログインが必要です" }, { status: 401 });
  }
  const raw = (new URL(request.url).searchParams.get("w") ?? "").trim().slice(0, 40);
  if (!/^[A-Za-z][A-Za-z'’-]*$/.test(raw)) {
    return NextResponse.json({ entry: null });
  }
  const candidates = lemmaCandidates(raw);
  if (candidates.length === 0) return NextResponse.json({ entry: null });

  // 大文字小文字を問わず探す（候補は小文字なので、小文字・先頭大文字の両方を渡す）
  const variants = Array.from(
    new Set(candidates.flatMap((c) => [c, c.charAt(0).toUpperCase() + c.slice(1)]))
  );
  const { data, error } = await supabaseAdmin
    .from("quiz_words")
    .select("id, word_en, part_of_speech, meaning_ja, other_meanings_ja, note_ja")
    .eq("active", true)
    .in("word_en", variants);
  if (error) {
    return NextResponse.json({ error: "取得に失敗しました" }, { status: 500 });
  }

  // 候補の優先順（入力そのまま→原形）で最初に見つかったものを返す
  for (const c of candidates) {
    const hit = (data ?? []).filter((r) => r.word_en.toLowerCase() === c);
    if (hit.length > 0) {
      const { data: flag } = await supabaseAdmin
        .from("quiz_word_weak_flags")
        .select("word_id")
        .eq("user_id", user.id)
        .in("word_id", hit.map((r) => r.id as string))
        .limit(1);
      return NextResponse.json(
        {
          entry: {
            wordId: hit[0].id as string,
            flagged: (flag ?? []).length > 0,
            word: hit[0].word_en,
            lemma: c !== raw.toLowerCase() ? c : null,
            senses: hit.map((r) => ({
              pos: r.part_of_speech as string | null,
              meaning: r.meaning_ja as string,
              others: (r.other_meanings_ja as string[] | null) ?? [],
              note: r.note_ja as string | null,
            })),
          },
        },
        { headers: { "Cache-Control": "no-store" } }
      );
    }
  }
  return NextResponse.json({ entry: null });
}
